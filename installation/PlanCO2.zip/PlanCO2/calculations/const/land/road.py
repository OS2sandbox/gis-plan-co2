ROAD_WIDTH_DICT = {
    'highway': 23.0,
    'heavy road': 7.5,
    'medium road': 6.5,
    'light road': 6.5,
    'bike path': 1.8,
    'pavement': 1.4,
    'path': 2.0
}
